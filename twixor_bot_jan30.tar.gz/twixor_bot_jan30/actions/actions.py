from typing import Dict, Text, Any, List, Union, Optional
import logging
from rasa_sdk import Tracker, Action
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import REQUESTED_SLOT
from rasa_sdk.events import SlotSet, EventType, Form
from rasa_sdk import Action, FormValidationAction
from rasa_sdk.events import SlotSet, FollowupAction
import re
import pandas as pd
import json
logger = logging.getLogger(__name__)
import requests
import random
from datetime import datetime
import psycopg2
from sqlalchemy import create_engine
from rasa_sdk.events import SessionStarted, ActionExecuted

class ActionSessionStart(Action):
    def name(self) -> Text:
        return "action_first_message"

    async def run(self, dispatcher, tracker, domain):
        # Trigger the first action
        #dispatcher.utter_message("This is my custom action")
        # Get the intent of the first user message
        intent = tracker.latest_message['intent'].get('name')
        senderid = tracker.sender_id
        #print("senderid :",senderid)

        #dispatcher.utter_message("This is the first action")

        conn = psycopg2.connect(host="139.59.46.169", database="analytics", user="analytics", password="analytics")
        cursor = conn.cursor()

        query = """
        SELECT sender_id, (data::json)->>'text' as message_text, (data::json)->>'event' as event_type, (data::json)->'data'->'buttons' as buttons
        FROM events
        WHERE sender_id='d7412b99dd5544aea8155aa7a6f76018' AND ((data::json)->>'event' = 'user' OR (data::json)->>'event' = 'bot');
        """
        #d7412b99dd5544aea8155aa7a6f76018
        cursor.execute(query)
        
        # Fetch the results
        rows = cursor.fetchall()    

        conn.commit()
        cursor.close()
        conn.close()
        print("connection close")
        
        # Loop through the results and print the messages with labels
        for row in rows:
            sender_id, message_text, event_type, buttons = row
            label = "user:" if event_type == "user" else "bot: "
            print(f"{label} {message_text}")
            if buttons:
                for button in buttons:
                    print(f"  - {button['title']}")                  

        # Revert to default action behavior
        return []

class FallbackAction(Action):
    def name(self) -> Text:
        return "action_out_of_scope"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # Get the user message from the tracker
        user_message = tracker.latest_message.get('text')

        # Prepare the input JSON for the API
        input_json = {
            "input": user_message
        }

        # Send the POST request to the API
        response = requests.post("http://10.25.20.77:6000/fastchat", json=input_json)
#http://10.25.20.77:6000/fastchat
        # Check if the request was successful
        if response.status_code == 200:
            # Parse the API response
            response_json = response.json()
            # Get the result from the API response
            result = response_json.get("result")
            # Send the result as the reply to the user
            dispatcher.utter_message(result)
        else:
            # Handle the case where the API request failed
            dispatcher.utter_message("I'm sorry, I am currently unable to process your request. Please try again later.")
            dispatcher.utter_message("Please let me know if you have further query. if you don't have please say exit")
        return []

class CardTransactionIssueDisputeForm(Action):
    def name(self) -> Text:
        return "card_transaction_dispute_issue_form"#

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        possible_slots = ["creditcardno","card_transaction_issue", "amount","date"]
        required_slots = [random.sample(possible_slots, 2)]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]

class CardTransactionIssueUnauthorizedForm(Action):
    def name(self) -> Text:
        return "card_transaction_unauthorized_issue_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["creditcardno","card_transaction_issue","amount","date"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]


class ValidateCardTransactionIssueDisputeForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_card_transaction_issue_dispute_form"##

    def validate_creditcardno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        invalid_count = tracker.get_slot("invalid_count")
        print(invalid_count, type(invalid_count))
        if invalid_count is None:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'creditcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("Invalid credit card number.")
                invalid_count = 1
                return {'invalid_count' : invalid_count, 'creditcardno' : None, 'validator': True}

        elif int(invalid_count) < 2:
            # Remove any spaces from the input
            print("It came here")
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'invalid_count': 0, 'creditcardno': slot_value, 'validator': True}
            else:
                dispatcher.utter_message("Invalid credit card number.")
                invalid_count = int(invalid_count) + 1
                return {'invalid_count' : invalid_count, 'creditcardno' : None, 'validator': True}

        else:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'creditcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("You have exceeded the maximum number of invalid input attempts. We are transferring you to our live agent; you'll receive a call from our representative soon.")
                return {'requested_slot': None, 'validator': False, 'invalid_count': None, 'creditcardno': None}

    def validate_amount(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        # Check if the input consists of digits
        if slot_value.isdigit():
            return {'amount': slot_value}
        else:
            dispatcher.utter_message("Invalid amount. Please enter a valid digit.")
            return {'amount': None}

class ValidateCardTransactionIssueUnauthorizedForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_card_transaction_issue_unauthorized_form"#

    def validate_creditcardno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        invalid_count = tracker.get_slot("invalid_count")
        print(invalid_count, type(invalid_count))
        if invalid_count is None:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'creditcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("Invalid credit card number.")
                invalid_count = 1
                return {'invalid_count' : invalid_count, 'creditcardno' : None, 'validator': True}

        elif int(invalid_count) < 2:
            # Remove any spaces from the input
            print("It came here")
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'invalid_count': 0, 'creditcardno': slot_value, 'validator': True}
            else:
                dispatcher.utter_message("Invalid credit card number.")
                invalid_count = int(invalid_count) + 1
                return {'invalid_count' : invalid_count, 'creditcardno' : None, 'validator': True}

        else:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'creditcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("You have exceeded the maximum number of invalid input attempts. We are transferring you to our live agent; you'll receive a call from our representative soon.")
                return {'requested_slot': None, 'validator': False, 'invalid_count': None, 'creditcardno': None}

    def validate_amount(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        # Check if the input consists of digits
        if slot_value.isdigit():
            return {'amount': slot_value}
        else:
            dispatcher.utter_message("Invalid amount. Please enter a valid digit.")
            return {'amount': None}


class CardTransactionIssueDisputeRegister(Action):
    def name(self) -> Text:
        return "card_transaction_issue_dispute_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        creditcardno = tracker.get_slot("creditcardno")
        card_transaction_issue = tracker.get_slot("card_transaction_issue")
        user_id = tracker.sender_id
        print("USER ID IS :",user_id)
        # Generate a 6-digit random number
        #card_transaction_complaint_number = random.randint(100000, 999999)
        dispatcher.utter_message("We sincerely apologize for any inconvenience caused. Your concern is of utmost importance to us. Rest assured, our dedicated team is actively investigating the issue, and we are committed to resolving it as quickly as possible. Your patience is highly appreciated. In the meantime, we've transferred this to our specialized team to ensure a thorough and efficient resolution. Thank you for your understanding and cooperation")
        return [
           SlotSet("creditcardno", None),
           SlotSet("card_transaction_issue", None),
           SlotSet("amount", None),
           SlotSet("date", None),
           SlotSet("card_type", None),
        ]

class CardTransactionIssueUnauthorizedRegister(Action):
    def name(self) -> Text:
        return "card_transaction_issue_unauthorized_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        creditcardno = tracker.get_slot("creditcardno")
        card_transaction_issue = tracker.get_slot("card_transaction_issue")
        user_id = tracker.sender_id
        reason_for_block=card_transaction_issue
        date=tracker.get_slot("date")
        amount=tracker.get_slot("amount")
        print("USER ID IS :",user_id)
        dispatcher.utter_message("Thank you for providing the details. I'm sorry for the inconvenience occured on {} of {} rupees. I'm going to verify the information and, as a precaution, I'll go ahead and block your card to prevent any further unauthorized transactions.\nDo you want to block your card?".format(date, amount))
        # Generate a 6-digit random number
        card_transaction_complaint_number = random.randint(100000, 999999)
        return [
           SlotSet("card_transaction_issue", None),
           SlotSet("reason_for_card_block", reason_for_block),
           SlotSet("cardno_for_block", creditcardno),
           SlotSet("amount", None),
           SlotSet("date", None),
           ]

class CardBlockForm(Action):
    def name(self) -> Text:
        return "card_block_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["card_type", "reason_for_card_block", "cardno_for_block"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]


class ValidateCardBlockForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_card_block_form"

    def validate_card_type(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        # Check if the input consists of digits
        if 'credit card' in slot_value or 'debit card'in slot_value:
            return {'card_type': slot_value}
        else:
            dispatcher.utter_message("Invalid card type.")
            return {'card_type': None}

    def validate_cardno_for_block(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        invalid_count = tracker.get_slot("invalid_count")
        print(invalid_count, type(invalid_count))
        if invalid_count is None:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'cardno_for_block': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("Invalid card number.")
                invalid_count = 1
                return {'invalid_count' : invalid_count, 'cardno_for_block' : None, 'validator': True}

        elif int(invalid_count) < 2:
            # Remove any spaces from the input
            print("It came here")
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'invalid_count': 0, 'cardno_for_block': slot_value, 'validator': True}
            else:
                dispatcher.utter_message("Invalid card number.")
                invalid_count = int(invalid_count) + 1
                return {'invalid_count' : invalid_count, 'cardno_for_block' : None, 'validator': True}

        else:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'cardno_for_block': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("You have exceeded the maximum number of invalid input attempts. We are transferring you to our live agent; you'll receive a call from our representative soon.")
                return {'requested_slot': None, 'validator': False, 'invalid_count': None, 'cardno_for_block': None}


class CardBlockRegister(Action):
    def name(self) -> Text:
        return "card_block_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:

        dispatcher.utter_message("We have successfully blocked your card")

        return [
           SlotSet("reason_for_card_block", None),
           SlotSet("creditcardno", None),
           SlotSet("otp", None),
        ]

class DontBlockCardRegister(Action):
    def name(self) -> Text:
        return "dont_block_card_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:

        dispatcher.utter_message("Not blocking card. ")

        return [
           SlotSet("card_type", None),
           SlotSet("creditcardno", None),
           SlotSet("reason_for_card_block", None),
          SlotSet("creditcardno", None),
        ]


class ActionGenerateOTP(Action):
    def name(self) -> Text:
        return "action_generate_otp"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        dispatcher.utter_message("Generating OTP Form")


        #Connect to PostgreSQL database
        #generated_otp = random.randint(100000, 999999)
        generated_otp = 505050
        print("Generated OTP :", generated_otp)
        time=datetime.now()#

        df = pd.DataFrame(columns=["generated_on", "otp"],data = [[time, generated_otp]])
        #connection_string = f'postgresql://{user_name}:{passwd}@{host_name}:5432/{db_name}'
        #engine = create_engine(f'postgresql://analytics:analytics@localhost:5432/analytics')

        #df.to_sql('otp_store',engine,if_exists='append',index=False)
        #engine.dispose()

        return []


class OTPForm(Action):
    def name(self) -> Text:
        return "otp_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["otp"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]

class ActionAskOTP(Action):
    def name(self) -> Text:
        return "action_ask_otp"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:

        dispatcher.utter_message(text="We need confirmation from you. Please enter the OTP sent to your registerd mobile number")
 
        return []


class ValidateOTPForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_otp_form"

    def validate_otp(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

#        slot_value = str(slot_value)
#        if len(slot_value) == 6 and slot_value.isdigit():
#            conn = psycopg2.connect(host="localhost", database="analytics", user="analytics", password="analytics")
#            df = pd.read_sql("SELECT otp FROM otp_store ORDER BY generated_on DESC LIMIT 1", conn)
#            conn.close()
#            print("connection close")
#            print("OTP from DB :", df["otp"][0])
#            otp = df["otp"][0]

#            if slot_value == str(otp):
#                return {'otp': slot_value}
#            else:
#                dispatcher.utter_message("OTP not matching.")
#                return {'otp': None}
#            return {'otp': slot_value}

#        else:
#            dispatcher.utter_message("Invalid OTP. Please enter a 6-digit number.")
#            return {'otp': None}

        slot_value = str(slot_value)
        invalid_count = tracker.get_slot("invalid_count")
        print(":::", invalid_count)
        if invalid_count is None:

            if len(slot_value) == 6 and slot_value.isdigit():
                #conn = psycopg2.connect(host="localhost", database="analytics", user="analytics", password="analytics")
                #df = pd.read_sql("SELECT otp FROM otp_store ORDER BY generated_on DESC LIMIT 1", conn)
                #conn.close()
                #print("connection close")
#                print("OTP from DB :", df["otp"][0])
                #otp = df["otp"][0]
                otp = 505050

                if slot_value == str(otp):
                    return {'otp': slot_value, 'invalid_count': 0, 'validator': True}
                else:
                    dispatcher.utter_message("OTP not matching.")
                    invalid_count = 1
                    return {'otp': None, 'invalid_count': invalid_count, 'validator': True}
            else:
                dispatcher.utter_message("Invalid OTP.")
                invalid_count = 1
                return {'otp': None, 'invalid_count': invalid_count, 'validator': True}

        elif int(invalid_count) < 2:

            if len(slot_value) == 6 and slot_value.isdigit():
                #conn = psycopg2.connect(host="localhost", database="analytics", user="analytics", password="analytics")
                #df = pd.read_sql("SELECT otp FROM otp_store ORDER BY generated_on DESC LIMIT 1", conn)
                #conn.close()
                print("connection close")
                #print("OTP from DB :", df["otp"][0])
                #otp = df["otp"][0]
                otp = 505050

                if slot_value == str(otp):
                    return {'otp': slot_value, 'invalid_count': 0, 'validator': True}
                else:
                    dispatcher.utter_message("OTP not matching.")
                    invalid_count = int(invalid_count) + 1
                    return {'otp': None, 'invalid_count': invalid_count, 'validator': True}
            else:
                dispatcher.utter_message("Invalid OTP.")
                invalid_count = int(invalid_count) + 1
                return {'otp': None, 'invalid_count': invalid_count, 'validator': True}

        else:

            if len(slot_value) == 6 and slot_value.isdigit():
                #conn = psycopg2.connect(host="localhost", database="analytics", user="analytics", password="analytics")
                #df = pd.read_sql("SELECT otp FROM otp_store ORDER BY generated_on DESC LIMIT 1", conn)
                #conn.close()
                #print("connection close")
                #print("OTP from DB :", df["otp"][0])
                #otp = df["otp"][0]
                otp = 505050

                if slot_value == str(otp):
                    return {'otp': slot_value, 'invalid_count': 0, 'validator': True}
                else:
                    dispatcher.utter_message("OTP not matching.")
                    invalid_count = int(invalid_count) + 1
                    return {'otp': None, 'invalid_count': invalid_count, 'validator': True}
            else:
                dispatcher.utter_message("Invalid OTP.")
                return {'otp': None, 'requested_slot': None, 'validator': False, 'invalid_count': 0,}

class OtpFormRegister(Action):
    def name(self) -> Text:
        return "otp_form_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        card_type = tracker.get_slot("card_type")
        random_digits = [random.randint(0, 9) for _ in range(6)]
        random_digits_str = ''.join(map(str, random_digits))
        message =  "We have successfully blocked your card. Your reference number is {}. \nPlease let me know if you have  further query? otherwise say exit".format(random_digits_str)
        dispatcher.utter_message(message)
        return [
            SlotSet("card_type", None),
            SlotSet("otp", None),
            SlotSet("cardno_for_block", None),
            SlotSet("reason_for_card_block", None),
            ]


class ActionChooseYourCard(Action):
    def name(self) -> Text:
        return "action_choose_your_card"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        dispatcher.utter_message("Below are the cards registered with your number. Which card you want to block. \n4657\n4000\n0111")
        return []

class CardTransactionIssueForm(Action):
    def name(self) -> Text:
        return "card_transaction_issue_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["card_type"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]

class ValidateCardTransactionIssueForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_card_transaction_issue_form"

    def validate_card_type(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        # Check if the input consists of digits
        if 'credit card' in slot_value or 'debit card'in slot_value:
            return {'card_type': slot_value}
        else:
            dispatcher.utter_message("Invalid card type.")
            return {'card_type': None}

class CardTransactionIssueRegister(Action):
    def name(self) -> Text:
        return "card_transaction_issue_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        card_type = tracker.get_slot("card_type")
        dispatcher.utter_message("card type is {}".format(card_type))
###############Redirect to particular card type form based on card type
        return []
#           SlotSet("card_type", None),
 #          ]

class DebitCardTransactionCardIssueForm(Action):
    def name(self) -> Text:
        return "debit_card_transaction_card_issue_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["debitcardno","card_transaction_issue", "date", "transaction_location"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]

class DebitCardTransactionMoneyIssueForm(Action):
    def name(self) -> Text:
        return "debit_card_transaction_money_issue_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["debitcardno","card_transaction_issue", "amount", "date", "transaction_location"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]

class DebitCardTransactionMoneyIssue2Form(Action):
    def name(self) -> Text:
        return "debit_card_transaction_money_issue2_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["card_transaction_issue", "amount", "date", "transaction_location"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]


class ValidateDebitCardTransactionCardIssueForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_debit_card_transaction_card_issue_form"

    def validate_debitcardno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        invalid_count = tracker.get_slot("invalid_count")
        print(invalid_count, type(invalid_count))
        if invalid_count is None:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'debitcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("Invalid debit card number.")
                invalid_count = 1
                return {'invalid_count' : invalid_count, 'debitcardno' : None, 'validator': True}

        elif int(invalid_count) < 2:
            # Remove any spaces from the input
            print("It came here")
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'invalid_count': 0, 'debitcardno': slot_value, 'validator': True}
            else:
                dispatcher.utter_message("Invalid debit card number.")
                invalid_count = int(invalid_count) + 1
                return {'invalid_count' : invalid_count, 'debitcardno' : None, 'validator': True}
        else:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'debitcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("You have exceeded the maximum number of invalid input attempts. We are transferring you to our live agent; you'll receive a call from our representative soon.")
                return {'requested_slot': None, 'validator': False, 'invalid_count': None, 'debitcardno': None}

class ValidateDebitCardTransactionMoneyIssueForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_debit_card_transaction_money_issue_form"#

    def validate_debitcardno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        invalid_count = tracker.get_slot("invalid_count")
        print(invalid_count, type(invalid_count))
        if invalid_count is None:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'debitcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("Invalid debit card number.")
                invalid_count = 1
                return {'invalid_count' : invalid_count, 'debitcardno' : None, 'validator': True}

        elif int(invalid_count) < 2:
            # Remove any spaces from the input
            print("It came here")
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'invalid_count': 0, 'debitcardno': slot_value, 'validator': True}
            else:
                dispatcher.utter_message("Invalid debit card number.")
                invalid_count = int(invalid_count) + 1
                return {'invalid_count' : invalid_count, 'debitcardno' : None, 'validator': True}
        else:
            # Remove any spaces from the input
            slot_value = "".join(str(slot_value).split())
            # Check if the length is exactly 4 and if it consists of digits
            if len(slot_value) == 4 and slot_value.isdigit():
                return {'debitcardno': slot_value, 'invalid_count': 0, 'validator': True}
            else:
                dispatcher.utter_message("You have exceeded the maximum number of invalid input attempts. We are transferring you to our live agent; you'll receive a call from our representative soon.")
                return {'requested_slot': None, 'validator': False, 'invalid_count': None, 'debitcardno': None}

class DebitCardTransactionCardIssueRegister(Action):
    def name(self) -> Text:
        return "debit_card_transaction_card_issue_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:

        # Get all the slot values from the tracker
        debitcardno = tracker.get_slot("debitcardno")
        card_transaction_issue = tracker.get_slot("card_transaction_issue")
        date = tracker.get_slot("date")
        transaction_location = tracker.get_slot("transaction_location")

        message = "We sincerely apologize for any inconvenience caused. Your concern is of utmost importance to us. Rest assured, our dedicated team is actively investigating the issue, and we are committed to resolving it as quickly as possible. Your patience is highly appreciated. In the meantime, we've transferred this to our specialized team to ensure a thorough and efficient resolution."
        dispatcher.utter_message(message)
        dispatcher.utter_message("Please let me know if you have further query. if you don't have please say exit")
        return [
           SlotSet("debitcardno", None),
           SlotSet("card_transaction_issue", None),
           SlotSet("date", None),
           SlotSet("transaction_location", None),
           SlotSet("card_type", None),
        ]
class DebitCardTransactionMoneyIssueRegister(Action):
    def name(self) -> Text:
        return "debit_card_transaction_money_issue_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        debitcardno = tracker.get_slot("debitcardno")
        card_transaction_issue = tracker.get_slot("card_transaction_issue")
        amount = tracker.get_slot("amount")
        date = tracker.get_slot("date")
        transaction_location = tracker.get_slot("transaction_location")

        message = "We sincerely apologize for any inconvenience caused. Your concern is of utmost importance to us. Rest assured, our dedicated team is actively investigating the issue, and we are committed to resolving it as quickly as possible. Your patience is highly appreciated. In the meantime, we've transferred this to our specialized team to ensure a thorough and efficient resolution"
        dispatcher.utter_message(message)
        dispatcher.utter_message("Please let me know if you have further query. if you don't have please say exit")
        return [
           SlotSet("debitcardno", None),
           SlotSet("card_transaction_issue", None),
           SlotSet("amount", None),
           SlotSet("date", None),
           SlotSet("transaction_location", None),
           SlotSet("card_type", None),
        ]

class DebitCardTransactionMoneyIssue2Register(Action):
    def name(self) -> Text:
        return "debit_card_transaction_money_issue2_register"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        card_transaction_issue = tracker.get_slot("card_transaction_issue")
        amount = tracker.get_slot("amount")
        date = tracker.get_slot("date")
        transaction_location = tracker.get_slot("transaction_location")

        message = "We sincerely apologize for any inconvenience caused. Your concern is of utmost importance to us. Rest assured, our dedicated team is actively investigating the issue, and we are committed to resolving it as quickly as possible. Your patience is highly appreciated."
        dispatcher.utter_message(message)
        dispatcher.utter_message("Please let me know if you have further query. if you don't have please say exit")
        return [
           SlotSet("card_transaction_issue", None),
           SlotSet("amount", None),
           SlotSet("date", None),
           SlotSet("transaction_location", None),
           SlotSet("card_type", None),
        ]

class MobileNumberForm(Action):
    def name(self) -> Text:
        return "mobile_number_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["mobileno"]
        for slot_name in required_slots:
            print(tracker.slots.get(slot_name))
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
       # All slots are filled.
        return [SlotSet("requested_slot", None)]

class ValidateMobileNumberForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_mobile_number_form"

    def validate_mobileno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        invalid_count = tracker.get_slot("invalid_count")
        print(invalid_count, type(invalid_count))
        if invalid_count is None:

            if type(slot_value)==str:
                slot_value = "".join(slot_value.split())
            elif type(slot_value)==list:
                slot_value = "".join(slot_value)
            print(slot_value)
            if len(str(slot_value))==10:
                validity = re.fullmatch("[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]",str(slot_value))
                if validity!=None:
                    return {'mobileno':slot_value, 'invalid_count': 0, 'validator': True}
                
                else:
                    dispatcher.utter_message("Invalid mobile number")
                    invalid_count = 1
                    return {'mobileno': None, 'invalid_count' : invalid_count, 'validator': True}
            else:
                dispatcher.utter_message("Invalid mobile number")
                invalid_count = 1
                return {'mobileno': None, 'invalid_count' : invalid_count, 'validator': True}

        elif int(invalid_count) < 2:

            if type(slot_value)==str:
                slot_value = "".join(slot_value.split())
            elif type(slot_value)==list:
                slot_value = "".join(slot_value)
            print(slot_value)
            if len(str(slot_value))==10:
                validity = re.fullmatch("[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]",str(slot_value))
                if validity!=None:
                    return {'mobileno':slot_value, 'invalid_count': 0, 'validator': True}

                else:
                    dispatcher.utter_message("Invalid mobile number")
                    invalid_count = int(invalid_count) + 1
                    return {'mobileno': None, 'invalid_count' : invalid_count, 'validator': True}
            else:
                dispatcher.utter_message("Invalid mobile number")
                invalid_count = int(invalid_count) + 1
                return {'mobileno': None, 'invalid_count' : invalid_count, 'validator': True}

        else:

            if type(slot_value)==str:
                slot_value = "".join(slot_value.split())
            elif type(slot_value)==list:
                slot_value = "".join(slot_value)
            print(slot_value)
            if len(str(slot_value))==10:
                validity = re.fullmatch("[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]",str(slot_value))
                if validity!=None:
                    return {'mobileno':slot_value, 'invalid_count': 0, 'validator': True}

                else:
                    dispatcher.utter_message("You have exceeded the maximum number of invalid input attempts. We are transferring you to our live agent; you'll receive a call from our representative soon.")
                    return {'requested_slot': None, 'mobileno': None, 'validator': False, 'invalid_count': None,}
            else:
                dispatcher.utter_message("You have exceeded the maximum number of invalid input attempts. We are transferring you to our live agent; you'll receive a call from our representative soon..")
                return {'requested_slot': None, 'mobileno': None, 'validator': False, 'invalid_count': None}



class CurrencyExchangeForm(Action):
    def name(self) -> Text:
        return "currency_exchange_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["to_currency", "exchange_amount"]
        for slot_name in required_slots:
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
        # All slots are filled.
        return [SlotSet("requested_slot", None)]

class CurrencyExchangeDetailsStore(Action):
    def name(self) -> Text:
        return "currency_exchange_details_store"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        to_currency = tracker.get_slot("to_currency")
        amount_to_exchange = tracker.get_slot("amount_to_exchange")

        dispatcher.utter_message(
            f"Collected Details are :\nTo currency: {to_currency}\nExchange Amount: {amount_to_exchange}")

        dispatcher.utter_message("Thank you. Your currency will be exchanged, and you will be notified via SMS or email")
        dispatcher.utter_message("Please let me know if you have further query. if you don't have please say exit")
        return [
            SlotSet("to_currency", None),
            SlotSet("amount_to_exchange", None),]

class AccountOpeningForm(Action):
    def name(self) -> Text:
        return "account_opening_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["account_type","name", "dob", "mobileno" ,"emailid", "adharno"]
        for slot_name in required_slots:
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
        # All slots are filled.
        return [SlotSet("requested_slot", None)]

class ValidateAccountOpeningForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_account_opening_form"

    def validate_mobileno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
    
        print(tracker.sender_id)
        print(type(slot_value))
        #slot_value = "".join(slot_value.split())
        if type(slot_value)==str:
            slot_value = "".join(slot_value.split())
        elif type(slot_value)==list:
            slot_value = "".join(slot_value)
        print(slot_value)
        if len(str(slot_value))==10:
            validity = re.fullmatch("[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]",str(slot_value))
            if validity!=None:
                return {'mobileno':slot_value}
                
            else:
                dispatcher.utter_message("Invalid mobile number")
                return {'mobileno': None}
        else:
            dispatcher.utter_message("Invalid mobile number")
        return {'mobileno': None}

    def validate_emailid(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
    
        if type(slot_value) == str:
            slot_value = slot_value.strip()
        elif type(slot_value) == list:
            slot_value = "".join(slot_value)
    
        # Define the regular expression for a valid email
        email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        
        # Check if the email is valid
        if re.match(email_regex, slot_value):
            return {'emailid': slot_value}
        else:
            dispatcher.utter_message("Invalid email address")
            return {'emailid': None}

    def validate_dob(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        print(slot_value, "++++++++++++")
        try:
            print("here")
            #dob = datetime.strptime(slot_value, "%d-%m-%Y")
            # Calculate age
            return {'dob': slot_value}
        except ValueError:
            print("Here also")
            dispatcher.utter_message("Invalid date of birth")
            return {'dob': None}

class AccountOpeningDetailsStore(Action):
    def name(self) -> Text:
        return "account_opening_details_store"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        account_type = tracker.get_slot("account_type")
        name = tracker.get_slot("name")
        dob = tracker.get_slot("dob")
        mobilenumber = tracker.get_slot("mobileno")
        emailid = tracker.get_slot("emailid")
        adharno = tracker.get_slot("adharno")

        dispatcher.utter_message(
            f"Collected Details are :\nAccount Type: {account_type}\nName: {name}\nDate of Birth: {dob}\nMobile Number: {mobilenumber}\n"
            f"\nEmail: {emailid}"
        )

        dispatcher.utter_message("Thank you for choosing us.\nWe will proceed with creating your account, and you'll be notified once the account is created.")
        return [
            SlotSet("account_type", None),
            SlotSet("name", None),
            SlotSet("dob", None),
            SlotSet("mobileno", None),
            SlotSet("emailid", None),
            SlotSet("adharno", None),]


class CreditCardApplicationForm(Action):
    def name(self) -> Text:
        return "credit_card_application_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["name", "dob", "mobileno" ,"emailid", "adharno","occupation","monthly_income","credit_score","preferred_credit_limit"]
        for slot_name in required_slots:
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
        # All slots are filled.
        return [SlotSet("requested_slot", None)]

class ValidateCreditCardApplicationForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_credit_card_application_form"

    def validate_mobileno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        print(tracker.sender_id)
        print(type(slot_value))
        #slot_value = "".join(slot_value.split())
        if type(slot_value)==str:
            slot_value = "".join(slot_value.split())
        elif type(slot_value)==list:
            slot_value = "".join(slot_value)
        print(slot_value)
        if len(str(slot_value))==10:
            validity = re.fullmatch("[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]",str(slot_value))
            if validity!=None:
                return {'mobileno':slot_value}

            else:
                dispatcher.utter_message("Invalid mobile number")
                return {'mobileno': None}
        else:
            dispatcher.utter_message("Invalid mobile number")
        return {'mobileno': None}

    def validate_emailid(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        # Define the regular expression for a valid email
        email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'

        # Check if the email is valid
        if re.match(email_regex, slot_value):
            return {'emailid': slot_value}
        else:
            dispatcher.utter_message("Invalid email address")
            return {'emailid': None}

    def validate_dob(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        print(slot_value, "++++++++++++")
        try:
            print("here")
            #dob = datetime.strptime(slot_value, "%d-%m-%Y")
            # Calculate age
            return {'dob': slot_value}
        except ValueError:
            print("Here also")
            dispatcher.utter_message("Invalid date of birth")
            return {'dob': None}

    def validate_monthly_income(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        try:
            # Convert the slot value to a float
            monthly_income = float(slot_value)

            # Check if the value is non-negative
            if monthly_income >= 0:
                return {'monthly_income': monthly_income}
            else:
                dispatcher.utter_message("Monthly income should be a non-negative numeric value.")
                return {'monthly_income': None}

        except ValueError:
            dispatcher.utter_message("Invalid monthly income. Please provide a numeric value.")
            return {'monthly_income': None}

    def validate_credit_score(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        try:
            # Convert the slot value to an integer
            credit_score = int(slot_value)

            # Check if the value is within a valid credit score range
            if 300 <= credit_score <= 850:
                return {'credit_score': credit_score}
            else:
                dispatcher.utter_message("Credit score should be a numeric value between 300 and 850.")
                return {'credit_score': None}

        except ValueError:
            dispatcher.utter_message("Invalid credit score. Please provide a numeric value.")
            return {'credit_score': None}

    def validate_preferred_credit_limit(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        try:
            # Convert the slot value to a float
            preferred_credit_limit = float(slot_value)

            # Check if the value is non-negative
            if preferred_credit_limit >= 0:
                return {'preferred_credit_limit': preferred_credit_limit}
            else:
                dispatcher.utter_message("Preferred credit limit should be a non-negative numeric value.")
                return {'preferred_credit_limit': None}

        except ValueError:
            dispatcher.utter_message("Invalid preferred credit limit. Please provide a numeric value.")
            return {'preferred_credit_limit': None}

class CreditCardApplicationStore(Action):
    def name(self) -> Text:
        return "credit_card_application_store"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        name = tracker.get_slot("name")
        dob = tracker.get_slot("dob")
        mobilenumber = tracker.get_slot("mobileno")
        emailid = tracker.get_slot("emailid")
        adharno = tracker.get_slot("adharno")

        dispatcher.utter_message("We have received your credit card application and will notify you once it has been processed. Thank you for choosing")
        dispatcher.utter_message("Please let me know if you have other query.")
        return [
            SlotSet("name", None),
            SlotSet("dob", None),
            SlotSet("mobileno", None),
            SlotSet("emailid", None),
            SlotSet("adharno", None),
            SlotSet("occupation", None),
            SlotSet("monthly_income", None),
            SlotSet("credit_score", None),
            SlotSet("preferred_credit_limit", None),]

class ComplaintForm(Action):
    def name(self) -> Text:
        return "complaint_form"

    async def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["name", "mobileno", "complaint"]
        for slot_name in required_slots:
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]
        # All slots are filled.
        return [SlotSet("requested_slot", None)]

class ValidateComplaintForm(FormValidationAction):
    def name(self) -> Text:
        return "validate_complaint_form"

    def validate_mobileno(
            self, slot_value: Any, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:

        print(tracker.sender_id)
        print(type(slot_value))
        #slot_value = "".join(slot_value.split())
        if type(slot_value)==str:
            slot_value = "".join(slot_value.split())
        elif type(slot_value)==list:
            slot_value = "".join(slot_value)
        print(slot_value)
        if len(str(slot_value))==10:
            validity = re.fullmatch("[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]",str(slot_value))
            if validity!=None:
                return {'mobileno':slot_value}

            else:
                dispatcher.utter_message("Invalid mobile number")
                return {'mobileno': None}
        else:
            dispatcher.utter_message("Invalid mobile number")
        return {'mobileno': None}

class ComplaintStore(Action):
    def name(self) -> Text:
        return "complaint_store"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:
        # Get all the slot values from the tracker
        name = tracker.get_slot("name")
        mobilenumber = tracker.get_slot("mobileno")
        complaint = tracker.get_slot("complaint")

        dispatcher.utter_message("I apologize for any inconvenience you've faced. Your concern is important to us, and we're actively investigating the issue. We'll ensure to address it promptly and get back to you with a resolution")
        dispatcher.utter_message("Please let me know if you have other query.")
        return [
            SlotSet("name", None),
            SlotSet("mobileno", None),
            SlotSet("complaint", None),]

from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import openai

class ActionChatGPT(Action):
    def name(self) -> Text:
        return "action_chatgpt"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        # Set your OpenAI API key
        openai.api_key = 'your-api-key'  # Replace with your actual API key

        # Get user input from the tracker
        user_input = tracker.latest_message['text']

        # Use the ChatGPT API for generating responses
        response = self.get_chat_response(user_input)

        # Send the response to the user
        dispatcher.utter_message(text=response)

        return []

    def get_chat_response(self, prompt: str) -> str:
        response = openai.Completion.create(
            model="text-davinci-002",
            prompt=prompt,
            max_tokens=100
        )
        return response.choices[0].text.strip()

import openai

class ActionChatGPT(Action):
    def name(self) -> Text:
        return "action_chatgpt"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        # Set your OpenAI API key
        openai.api_key = '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'  # Replace with your actual API key

        # Get user input from the tracker
        user_input = tracker.latest_message['text']

        # Use the ChatGPT API for generating responses
        response = self.get_chat_response(user_input)

        # Send the response to the user
        dispatcher.utter_message(text=response)

        return []

    def get_chat_response(self, prompt: str) -> str:
        response = openai.Completion.create(
#            model="text-davinci-003",
            prompt=prompt,
            max_tokens=100
        )
        return response.choices[0].text.strip()
