import subprocess
import os
from rasa.shared.exceptions import YamlSyntaxException

def train_rasa_model():
    try:
        # Change the relative path to your Rasa project directory
        project_directory = "~/twixor-bot-dec16"

        # Expand the user path to get the absolute path
        project_directory = os.path.expanduser(project_directory)

        # Change to the Rasa project directory
        os.chdir(project_directory)

        # Run 'rasa train' command and capture the output
        result = subprocess.run(["rasa", "train"], capture_output=True, text=True)

        # Print the captured output
        print("result :",result.stdout)

        # Check if the success message is present in the output
        success_message = "Your Rasa model is trained and saved"
        if success_message in result.stdout:
            print("Model trained successfully!")
        else:
            print("Model training failed!")

        # Print warnings from stderr
        if result.stderr:
            print("Warnings during training:")
            warning_block = []
            next_line_is_warning = False

            for line in result.stderr.splitlines():
                if "WARNING" in line and "rasa.validator" in line:
                    next_line_is_warning = True
                    warning_block.append(line)
                elif next_line_is_warning:
                    warning_block.append(line)
                    # Check if the next line starts with a timestamp
                    if line.startswith("2024"):
                        print("\n".join(warning_block))
                        next_line_is_warning = False
                        warning_block = []

    except subprocess.CalledProcessError as e:
        print(f"Error during training: {e}")
        print("Command output:")
        print(e.stdout.decode())  # Print the captured output from the subprocess
        print("Model training failed!")

    except YamlSyntaxException as yaml_error:
        print(f"YAML Syntax Error: {yaml_error}")
        print(f"File: {yaml_error.filename}")
        print(f"Line: {yaml_error.problem_mark.line + 1}, Column: {yaml_error.problem_mark.column + 1}")
        print("You can use https://yamlchecker.com/ to validate the YAML syntax of your file.")
        print("Model training failed!")

    except Exception as ex:
        print("Exception type:", type(ex).__name__)
        print("Exception details:", ex)
        print("Model training failed!")

if __name__ == "__main__":
    train_rasa_model()
